# 人物关系与势力图谱管理规范

## 核心理念

**动态演化**：关系图不是静态的，而是随着情节发展不断扩展和修改
**以主角为核心**：所有关系从主角视角展开，随着主角的接触范围扩大
**分层展示**：核心关系→重要关系→次要关系→背景人物

---

## 一、人物关系图（动态演化）

### 1.1 关系图格式（Mermaid语法）

使用Mermaid语法绘制关系图，可在Markdown中直接渲染：

```mermaid
graph TD
    A[林远] -->|导师| B[陈国强]
    A -->|搭档/信任| C[苏雅]
    A -->|师徒| D[李明]
    A -->|政治合作| E[马克·约翰逊]
    A -->|对立→理解| B
    D -->|被利用| E
    E -->|女儿| F[艾米莉]
    B -->|二十年前实验| G[普罗米修斯号团队]
```

### 1.2 分卷关系图（动态扩展）

#### 卷1关系图（第1-10章）- 核心圈

```mermaid
graph TD
    A[林远<br/>主角] -->|导师/尊重| B[陈国强<br/>62岁]
    A -->|搭档/信任12年| C[苏雅<br/>35岁]
    A -->|师徒/助手| D[李明<br/>25岁]
    A -->|政治合作| E[马克<br/>联合国代表]
    
    B -->|二十年前隐瞒| G[星门秘密]
    C -->|量子破译专家| H[技术核心]
    D -->|冲动/背叛| E
    E -->|保护女儿| F[艾米莉<br/>8岁]
    
    classDef protagonist fill:#ff9999
    classDef ally fill:#99ff99
    classDef antagonist fill:#9999ff
    classDef neutral fill:#ffff99
    
    class A protagonist
    class B,C,D ally
    class E antagonist
    class F neutral
```

**关系说明：**
- 林远（主角）：天体物理学家，38岁
- 陈国强（导师→阻碍→牺牲）：62岁，20年前隐瞒真相
- 苏雅（搭档）：35岁，12年合作伙伴
- 李明（助手→背叛→成长）：25岁，被马克利用
- 马克（反对者→理解者）：联合国代表，保护女儿
- 艾米莉（勇气象征）：8岁，马克的女儿

#### 卷2关系图（第11-30章）- 扩展圈

```mermaid
graph TD
    A[林远] -->|导师| B[陈国强]
    A -->|搭档| C[苏雅]
    A -->|守护者联盟| D[李明<br/>接替者]
    A -->|理解| E[马克]
    
    A -->|新接触| F[玛丽·杜邦<br/>法国代表]
    A -->|新接触| G[守护者联盟成员]
    
    E -->|女儿| H[艾米莉<br/>9岁→12岁]
    B -->|时间裂缝| I[所有时间线]
    D -->|时间裂缝中| J[锚点控制]
    
    F -->|支持启动| K[星际安全委员会]
    G -->|守护责任| L[星门]
    
    classDef protagonist fill:#ff9999
    classDef ally fill:#99ff99
    classDef new fill:#ffcc99
    classDef special fill:#cc99ff
    
    class A protagonist
    class B,C,D,E ally
    class F,G new
    class I,J special
```

**新增人物：**
- 玛丽·杜邦：法国代表，支持星门计划
- 守护者联盟成员：新一代守护者
- 关系变化：李明从背叛者变为接替者

#### 卷3关系图（第31-60章）- 更大圈层

```mermaid
graph TD
    A[林远] -->|联盟领导| B[守护者联盟]
    A -->|研究合作| C[苏雅]
    
    B -->|成员| D[李明<br/>年度返回]
    B -->|成员| E[玛丽·杜邦]
    B -->|成员| F[新成员1]
    B -->|成员| G[新成员2]
    
    A -->|接触外星文明| H[先行者<br/>纯能量形态]
    A -->|接触| I[其他文明代表]
    
    H -->|一百亿年守护| J[星门网络]
    J -->|连接| K[殖民地1<br/>柯伊伯带]
    J -->|连接| L[殖民地2<br/>比邻星]
    J -->|连接| M[殖民地3<br/>天狼星]
    
    I -->|交流| N[文明A]
    I -->|交流| O[文明B]
    I -->|交流| P[文明C]
    
    classDef protagonist fill:#ff9999
    classDef ally fill:#99ff99
    classDef alien fill:#99ccff
    classDef colony fill:#ccffcc
    classDef organization fill:#ffcc99
    
    class A protagonist
    class B,C,D,E,F,G organization
    class H,I,N,O,P alien
    class K,L,M colony
```

**大规模扩展：**
- 外星文明：先行者、其他文明代表
- 殖民地：柯伊伯带、比邻星、天狼星
- 多文明交流网络

### 1.3 关系图更新规则

**何时更新：**
1. 每5章检查一次关系变化
2. 新人物出现时立即添加
3. 关系性质改变时更新（如对立→理解）
4. 每卷结束时生成完整关系图

**更新内容：**
- 新增人物节点
- 新增/修改关系边
- 更新人物状态（年龄、位置、情绪）
- 标记重要关系变化

---

## 二、势力关系图

### 2.1 势力关系图格式

```mermaid
graph LR
    A[守护者联盟] -->|领导| B[林远]
    A -->|成员| C[苏雅]
    A -->|成员| D[李明]
    A -->|合作| E[联合国]
    
    E -->|支持| F[星际安全委员会]
    E -->|监管| G[全球殖民地]
    
    F -->|前主席| H[陈国强]
    F -->|现任| I[玛丽·杜邦]
    
    A -->|守护| J[星门]
    J -->|连接| K[先行者文明]
    J -->|连接| L[人类殖民地]
    J -->|连接| M[外星文明网络]
    
    classDef human fill:#99ff99
    classDef organization fill:#ffcc99
    classDef alien fill:#99ccff
    classDef gate fill:#cc99ff
    
    class B,C,D human
    class A,E,F,G,I organization
    class K,M alien
    class J gate
```

### 2.2 势力演化时间线

#### 阶段1：信号接收期（第1-10章）

```
联合国
  ├── 星际安全委员会（陈国强主席）
  ├── 特别代表（马克·约翰逊）
  └── 各国代表团
        ├── 支持派：美国、中国、印度
        ├── 反对派：俄罗斯
        └── 观望派：欧盟

深空信号研究所
  ├── 林远（首席科学家）
  ├── 苏雅（破译专家）
  └── 李明（助手）
```

#### 阶段2：星门启动期（第11-30章）

```
守护者联盟（新成立）
  ├── 联盟主席：林远
  ├── 技术总监：苏雅
  ├── 锚点控制：李明（时间裂缝中）
  └── 顾问：陈国强（重获自由）

联合国
  ├── 星际安全委员会（玛丽·杜邦主席）
  └── 殖民地管理部（新设立）

人类殖民地
  ├── 曙光站（柯伊伯带）
  ├── 比邻星基地（建设中）
  └── 天狼星勘探站（规划中）

外星文明
  └── 先行者（一百亿年守护者）
```

#### 阶段3：多文明交流期（第31-60章）

```
星际联盟（新成立）
  ├── 人类守护者联盟
  ├── 先行者文明
  ├── 文明A
  ├── 文明B
  └── 文明C

殖民地网络
  ├── 太阳系内
  │   ├── 曙光站（柯伊伯带）
  │   └── 火星基地
  ├── 半人马座
  │   └── 比邻星殖民地
  └── 天狼星系
      └── 天狼星殖民地

星门网络
  ├── 主星门（柯伊伯带）
  ├── 子星门1（比邻星）
  ├── 子星门2（天狼星）
  └── ...（更多星门）
```

### 2.3 势力关系更新规则

**何时更新：**
1. 新势力出现时
2. 势力关系改变时（合作→对立，或反之）
3. 势力规模变化时（扩张、分裂、合并）
4. 每卷结束时生成完整势力图

**更新内容：**
- 新增势力节点
- 新增/修改势力关系
- 更新势力规模/影响力
- 标记重要势力变化

---

## 三、地理位置图

### 3.1 太阳系地图

```mermaid
graph LR
    A[太阳] -->|1 AU| B[地球<br/>日内瓦总部]
    A -->|1.5 AU| C[火星<br/>基地]
    A -->|5 AU| D[木星<br/>观测站]
    A -->|30-50 AU| E[柯伊伯带<br/>星门+曙光站]
    
    E -->|4.3光年| F[比邻星<br/>殖民地]
    E -->|8.6光年| G[天狼星<br/>勘探站]
    
    classDef star fill:#ffff99
    classDef planet fill:#99ff99
    classDef gate fill:#cc99ff
    classDef colony fill:#ffcc99
    
    class A star
    class B,C,D planet
    class E gate
    class F,G colony
```

### 3.2 地图更新规则

**何时更新：**
1. 探索新地点时
2. 建立新基地/殖民地时
3. 星门网络扩展时
4. 每卷结束时更新完整地图

---

## 四、实现方案

### 4.1 文件结构

```
novels/小说名/
├── 图谱/
│   ├── 人物关系图.md（Mermaid语法）
│   ├── 势力关系图.md（Mermaid语法）
│   ├── 地理位置图.md（Mermaid语法）
│   ├── 时间线图谱.md（重要事件）
│   └── 伏笔线索图.md（伏笔埋设/回收）
├── 卷1/
├── 卷2/
└── ...
```

### 4.2 自动化生成脚本

创建Python脚本自动生成/更新关系图：

```python
# scripts/generate_relationship_graph.py
"""
自动生成人物关系图和势力关系图
基于人物档案和章节内容
"""

import re
from pathlib import Path

class RelationshipGraphGenerator:
    def __init__(self, novel_path):
        self.novel_path = Path(novel_path)
        self.characters = {}
        self.relationships = []
        self.factions = {}
        
    def parse_character_files(self):
        """解析人物档案"""
        pass
        
    def parse_chapters(self):
        """解析章节内容，提取关系"""
        # 使用正则表达式提取人物互动
        # "A对B说"、"A和B一起"、"A帮助B"等
        pass
        
    def generate_mermaid_graph(self):
        """生成Mermaid语法的关系图"""
        graph = "graph TD\n"
        
        # 添加人物节点
        for char, info in self.characters.items():
            graph += f'    {char}[{char}<br/>{info["age"]}岁]\n'
        
        # 添加关系边
        for rel in self.relationships:
            graph += f'    {rel["from"]} -->|{rel["type"]}| {rel["to"]}\n'
        
        return graph
        
    def update_graph(self, chapter_num):
        """根据新章节更新关系图"""
        # 解析新章节
        # 提取新人物/新关系
        # 更新关系图
        pass
        
    def export_graph(self, output_path):
        """导出关系图到Markdown文件"""
        pass

# 使用示例
generator = RelationshipGraphGenerator("novels/星门抉择")
generator.parse_character_files()
generator.parse_chapters()
graph = generator.generate_mermaid_graph()
generator.export_graph("novels/星门抉择/图谱/人物关系图.md")
```

### 4.3 半自动化更新流程

**创作完成后：**

```markdown
## 第X章创作完成后更新图谱

### 第一步：识别新人物
- [ ] 本章是否出现新人物？
- [ ] 如果有，添加到人物档案
- [ ] 确定与主角的关系

### 第二步：识别关系变化
- [ ] 本章是否有人物关系改变？
- [ ] 对立→合作？信任→背叛？
- [ ] 更新关系图

### 第三步：识别势力变化
- [ ] 本章是否有新势力出现？
- [ ] 势力关系是否改变？
- [ ] 更新势力图

### 第四步：更新地理信息
- [ ] 本章是否有新地点？
- [ ] 是否建立新基地？
- [ ] 更新地图

### 第五步：运行生成脚本
```bash
python scripts/generate_relationship_graph.py
```

### 第六步：人工审核
- [ ] 检查关系图是否准确
- [ ] 修正自动识别错误
- [ ] 补充遗漏的关系
```

---

## 五、实际应用示例

### 5.1 《星门抉择》关系图演化

#### 第1章结束时
```mermaid
graph TD
    A[林远] -->|导师| B[陈国强]
    A -->|搭档12年| C[苏雅]
    A -->|师徒| D[李明]
```

#### 第5章结束时
```mermaid
graph TD
    A[林远] -->|导师| B[陈国强]
    A -->|搭档| C[苏雅]
    A -->|师徒/已开除| D[李明]
    A -->|政治对立| E[马克]
    D -->|被利用| E
    E -->|女儿| F[艾米莉]
```

#### 第10章结束时
```mermaid
graph TD
    A[林远] -->|导师/理解| B[陈国强]
    A -->|搭档| C[苏雅]
    A -->|师徒/接替者| D[李明]
    A -->|理解| E[马克]
    E -->|女儿| F[艾米莉]
    B -->|时间裂缝| G[所有时间线]
    D -->|时间裂缝中| H[锚点控制]
```

### 5.2 关系变化追踪表

| 章节 | 人物A | 人物B | 关系变化 | 原因 |
|------|-------|-------|---------|------|
| 第1章 | 林远 | 陈国强 | 师徒/尊重 | 初始关系 |
| 第3章 | 林远 | 陈国强 | 师徒/分歧 | 星门计划分歧 |
| 第7章 | 林远 | 陈国强 | 师徒/和解 | 陈国强公开真相 |
| 第9章 | 林远 | 陈国强 | 师徒/敬佩 | 陈国强选择牺牲 |
| 第10章 | 林远 | 陈国强 | 师徒/平等 | 陈国强重获自由 |

---

## 六、工具推荐

### 6.1 Mermaid渲染工具

- **VS Code插件**：Mermaid Preview
- **在线编辑器**：https://mermaid.live
- **GitHub/GitLab**：原生支持Mermaid

### 6.2 关系图管理软件

- **Draw.io**：免费，支持多种图表
- **Obsidian**：支持Mermaid，适合知识管理
- **Notion**：支持内嵌Mermaid

### 6.3 自动化脚本

```bash
# 一键更新所有图谱
./scripts/update_all_graphs.sh

# 生成关系变化报告
python scripts/generate_relationship_report.py

# 检查关系一致性
python scripts/check_relationship_consistency.py
```

---

## 七、最佳实践

### 7.1 更新频率

| 图谱类型 | 更新频率 | 触发条件 |
|---------|---------|---------|
| 人物关系图 | 每5章 | 新人物/关系变化 |
| 势力关系图 | 每10章 | 新势力/势力变化 |
| 地理位置图 | 每卷 | 新地点/殖民地 |
| 时间线图谱 | 每章 | 重要事件 |
| 伏笔线索图 | 每章 | 埋设/回收伏笔 |

### 7.2 复杂度控制

**原则：** 一图不超过30个节点
- 超过30个节点 → 分层展示
- 核心圈（10人）
- 重要圈（20人）
- 次要圈（30人）
- 背景人物（另列清单）

### 7.3 版本控制

```
图谱/
├── 人物关系图-v1.md（第1-10章）
├── 人物关系图-v2.md（第11-20章）
├── 人物关系图-v3.md（第21-30章）
└── 人物关系图-latest.md（当前版本）
```

---

## 八、总结

### 核心价值

1. **可视化复杂关系** - 一图胜千言
2. **追踪动态演化** - 关系不是静态的
3. **发现逻辑漏洞** - 关系矛盾一目了然
4. **辅助情节规划** - 基于关系设计冲突
5. **保持连续性** - 避免前后矛盾

### 实施步骤

1. ✅ 创建图谱目录结构
2. ✅ 绘制初始关系图（第1章）
3. ✅ 每5章更新一次
4. ✅ 使用脚本辅助生成
5. ✅ 人工审核修正
6. ✅ 版本控制管理

### 适用场景

- ✅ 百章/千章长篇小说
- ✅ 多主角/多视角叙事
- ✅ 复杂势力关系
- ✅ 庞大世界观
- ✅ 长篇系列作品

---

**结论：** 关系图系统是长篇创作的**必备工具**，特别是对于人物众多、势力复杂、世界观庞大的小说。
