#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
上下文自检工具
帮助AI在每章创作前检查上下文完整性
"""

import json
import os
import re
import sys
from pathlib import Path


def load_outline(outline_path: str) -> dict:
    """加载大纲文件并提取关键信息"""
    if not os.path.exists(outline_path):
        return {'error': f'大纲文件不存在: {outline_path}'}
    
    with open(outline_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 提取TODO List状态
    todo_status = {
        '待创作': [],
        '进行中': [],
        '已完成': []
    }
    
    # 解析TODO项
    todo_pattern = r'- \[([ x])\] (第\d+章[：:].*?)(?=\n|$)'
    for match in re.finditer(todo_pattern, content):
        status = '已完成' if match.group(1) == 'x' else '待创作'
        chapter_info = match.group(2).strip()
        todo_status[status].append(chapter_info)
    
    # 提取章节摘要
    summaries = {}
    summary_pattern = r'### (第\d+章[：:].*?)\n\*\*摘要\*\*[：:]\s*(.*?)(?=\n---|\n###|$)'
    for match in re.finditer(summary_pattern, content, re.DOTALL):
        chapter_title = match.group(1).strip()
        summary_text = match.group(2).strip()
        summaries[chapter_title] = summary_text
    
    # 提取人物状态快照
    character_status = {}
    char_pattern = r'## 当前人物状态快照.*?### 主角\n(.*?)(?=### 反派|$)'
    char_match = re.search(char_pattern, content, re.DOTALL)
    if char_match:
        character_status['主角'] = char_match.group(1).strip()
    
    return {
        'todo_status': todo_status,
        'summaries': summaries,
        'character_status': character_status,
        'total_chapters': len(todo_status['已完成']) + len(todo_status['待创作'])
    }


def load_previous_chapter(chapter_dir: str, current_chapter: int) -> dict:
    """加载上一章文件内容"""
    prev_chapter_num = current_chapter - 1
    if prev_chapter_num < 1:
        return {'error': '当前是第一章，无上一章'}
    
    # 查找上一章文件
    chapter_files = list(Path(chapter_dir).glob(f'第{prev_chapter_num:02d}*.md'))
    if not chapter_files:
        return {'error': f'未找到第{prev_chapter_num}章文件'}
    
    with open(chapter_files[0], 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 提取结尾悬念
    ending_hook = ''
    hook_pattern = r'## 章节备注.*?本章悬念[：:]\s*(.*?)(?=\n|$)'
    hook_match = re.search(hook_pattern, content, re.DOTALL)
    if hook_match:
        ending_hook = hook_match.group(1).strip()
    
    return {
        'chapter_num': prev_chapter_num,
        'content': content,
        'ending_hook': ending_hook,
        'word_count': len(re.findall(r'[\u4e00-\u9fff]', content))
    }


def generate_context_checklist(outline_path: str, chapter_dir: str, current_chapter: int) -> str:
    """生成上下文自检清单"""
    outline_data = load_outline(outline_path)
    prev_chapter_data = load_previous_chapter(chapter_dir, current_chapter)
    
    checklist = []
    checklist.append('=' * 60)
    checklist.append(f'第{current_chapter}章 - 上下文自检清单')
    checklist.append('=' * 60)
    checklist.append('')
    
    # 1. 大纲状态检查
    checklist.append('【1】大纲状态检查')
    checklist.append(f'  总章节数: {outline_data.get("total_chapters", "未知")}')
    checklist.append(f'  已完成: {len(outline_data.get("todo_status", {}).get("已完成", []))} 章')
    checklist.append(f'  待创作: {len(outline_data.get("todo_status", {}).get("待创作", []))} 章')
    checklist.append('')
    
    # 2. 最近章节摘要
    checklist.append('【2】最近3章摘要（上下文参考）')
    summaries = outline_data.get('summaries', {})
    recent_summaries = list(summaries.items())[-3:]
    if recent_summaries:
        for title, summary in recent_summaries:
            checklist.append(f'  {title}:')
            checklist.append(f'    {summary[:100]}...' if len(summary) > 100 else f'    {summary}')
    else:
        checklist.append('  （暂无已完成章节）')
    checklist.append('')
    
    # 3. 上一章悬念
    checklist.append('【3】上一章悬念（必须回应）')
    if 'error' not in prev_chapter_data:
        checklist.append(f'  第{prev_chapter_data["chapter_num"]}章结尾悬念:')
        checklist.append(f'    {prev_chapter_data.get("ending_hook", "未明确设置")}')
        checklist.append(f'  上一章字数: {prev_chapter_data.get("word_count", 0)}')
    else:
        checklist.append(f'  {prev_chapter_data["error"]}')
    checklist.append('')
    
    # 4. 人物状态
    checklist.append('【4】当前人物状态')
    char_status = outline_data.get('character_status', {})
    if char_status:
        checklist.append(f'  主角状态:')
        checklist.append(f'    {char_status.get("主角", "未更新")}')
    else:
        checklist.append('  （人物状态快照未建立，请在创作后更新）')
    checklist.append('')
    
    # 5. 自检问题（AI必须回答）
    checklist.append('【5】上下文自检问题（创作前必须全部回答）')
    checklist.append('  □ 主角现在在哪里？情绪如何？')
    checklist.append('  □ 上一章的悬念是什么？本章如何回应？')
    checklist.append('  □ 有哪些未解的伏笔需要在本章提及或推进？')
    checklist.append('  □ 本章会埋下什么新伏笔？')
    checklist.append('  □ 本章结束后人物状态会如何变化？')
    checklist.append('')
    
    # 6. 周期性检查提示
    if current_chapter % 5 == 0:
        checklist.append('⚠️  提示：已完成5的倍数章节，请生成"全书状态快照"')
    if current_chapter % 10 == 0:
        checklist.append('⚠️  提示：已完成10的倍数章节，请执行"深度一致性检查"')
    checklist.append('')
    
    checklist.append('=' * 60)
    checklist.append('全部检查通过后，方可开始创作')
    checklist.append('=' * 60)
    
    return '\n'.join(checklist)


def main():
    """主函数"""
    if len(sys.argv) < 3:
        print('用法:')
        print('  python context_check.py <大纲文件路径> <章节目录> <当前章节号>')
        print('')
        print('示例:')
        print('  python context_check.py novels/故事/00-大纲.md novels/故事 5')
        return
    
    outline_path = sys.argv[1]
    chapter_dir = sys.argv[2]
    current_chapter = int(sys.argv[3])
    
    checklist = generate_context_checklist(outline_path, chapter_dir, current_chapter)
    print(checklist)
    
    # 可选：输出为JSON供程序化使用
    if len(sys.argv) > 4 and sys.argv[4] == '--json':
        outline_data = load_outline(outline_path)
        prev_chapter_data = load_previous_chapter(chapter_dir, current_chapter)
        
        output = {
            'chapter': current_chapter,
            'outline': outline_data,
            'previous_chapter': prev_chapter_data,
            'is_cycle_checkpoint': current_chapter % 5 == 0,
            'is_deep_check': current_chapter % 10 == 0
        }
        
        print('\n--- JSON OUTPUT ---')
        print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
